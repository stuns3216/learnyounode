//1-Hello word 

console.log('HELLO WORLD');