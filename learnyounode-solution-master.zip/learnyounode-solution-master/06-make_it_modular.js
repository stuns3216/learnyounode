//06-Make it modular 

var filterFn = require('./06_module.js')
var dir = process.argv[2]
var filterStr = process.argv[3]
 
filterFn(dir, filterStr, function (err, list) {
  if (err)
    return console.error('There was an error:', err)
 
  list.forEach(function (file) {
    console.log(file)
  })
})